package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Alumno implements Serializable {
	
	private int nia;
	
	private String nombre;
	
	private String apellidos;
	
	private char generoCaracter;
	
	 private LocalDate fechaNac;
	
	private String ciclo;
	
	private String curso;
	
	private String grupo;
	
	public Alumno(int nia, String nombre, String apellidos, char generoCaracter,  LocalDate fechaNac, String ciclo, String curso, String grupo) {
		
		this.nia = nia;
		
		this.nombre = nombre;
		
		this.apellidos = apellidos;
		
		this.generoCaracter = generoCaracter;
		
		this.fechaNac = fechaNac;
		
		this.ciclo = ciclo;
		
		this.curso = curso;
		
		this.grupo = grupo;
		
	}
	

	public int getNia() {
		return nia;
	}

	public String getNombre() {
		return nombre;
	}

	
	public String getApellidos() {
		return apellidos;
	}

	public char getGenero() {
		return generoCaracter;
	}

	public LocalDate getFechaNac() { 
		return fechaNac; 
		}

	public String getCiclo() {
		return ciclo;
	}

	public String getCurso() {
		return curso;
	}

	public String getGrupo() {
		return grupo;
	}

	@Override
	public String toString() {
		return "Alumno [nia=" + nia + ", nombre=" + nombre + ", apellidos=" + apellidos + ", generoCaracter="
				+ generoCaracter + ", fechaNac=" + fechaNac + ", ciclo=" + ciclo + ", curso=" + curso + ", grupo="
				+ grupo + "]";
	}
	
}
