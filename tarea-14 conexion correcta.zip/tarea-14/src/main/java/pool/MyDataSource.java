package pool;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class MyDataSource {

    private static HikariConfig config = new HikariConfig();
    
    private static HikariDataSource dataSource;

    static {
    	
        try {
            
        	config.setJdbcUrl("jdbc:mysql://localhost:3306/empresa?useSSL=false&serverTimezone=UTC");
        	
            config.setUsername("root");
            
            config.setPassword("manager03");

            config.addDataSourceProperty("maximumPoolSize", "10");
            
            config.addDataSourceProperty("cachePrepStmts", "true");
            
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

            dataSource = new HikariDataSource(config);

        } catch (Exception e) {

            System.err.println("Error al inicializar la fuente de datos (HikariCP):");
            
            e.printStackTrace();
            
            throw new RuntimeException("Fallo al inicializar la fuente de datos", e);
            
        }
        
    }

    private MyDataSource() {}

    public static Connection getConnection() throws SQLException {
    	
        if (dataSource == null) {
        	
            throw new SQLException("La fuente de datos no fue inicializada correctamente.");
        }
        
        return dataSource.getConnection();
    }
}
