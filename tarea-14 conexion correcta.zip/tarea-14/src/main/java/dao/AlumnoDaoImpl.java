package dao;

import java.sql.SQLException;
import java.util.List;

import model.Alumno;

public class AlumnoDaoImpl implements AlumnoDao{

	private static AlumnoDaoImpl instance;
	
	static {
		
		instance = new AlumnoDaoImpl();
		
	}
	
	private AlumnoDaoImpl(){}
	
	public static AlumnoDaoImpl getInstance() {
		
		return instance;
		
	}
	
	@Override
	public int add(Alumno emp) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Alumno getById(int id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Alumno> getAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(Alumno emp) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(int id) throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
