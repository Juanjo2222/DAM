package dao;

import java.sql.SQLException;
import java.util.List;

import model.Alumno;

public interface AlumnoDao {

	int add (Alumno emp) throws SQLException;
	
	Alumno getById(int id) throws SQLException;
	
	List<Alumno> getAll() throws SQLException;
	
	int update (Alumno emp) throws SQLException;
	
	void delete(int id) throws SQLException;
	
}
