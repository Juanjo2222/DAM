package tarea12;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;


public class main {

    private static final String URL = "jdbc:mysql://localhost:3306/Alumnos03";
    
    private static final String USER = "root";
    
    private static final String PASSWORD = "manager03";

    private static Connection conectarBaseDatos() throws SQLException {
    	
        return DriverManager.getConnection(URL, USER, PASSWORD);
        
    }
    
    private static int generarNIA() {
    	
        Scanner scanner = new Scanner(System.in);	        

		 boolean numeroCorrecto = false;
        
        String input = "";
        
        int niaValido = 0;
 
        while (!numeroCorrecto) {
        	
            input = scanner.nextLine();      
            
            if (input.matches("\\d+")) {
            	
           	 niaValido = Integer.parseInt(input);
                		                        
                numeroCorrecto = true;
                			                     
            } else {
            	
                System.out.println("Error: El NIA debe ser un número válido. Inténtalo de nuevo.");
            }
         
        }
        
        return niaValido;
		
	}

	private static char generarLetraGenero() {
		
		Scanner scanner = new Scanner(System.in);
		
		 String generoCompleto = scanner.nextLine();
			
        while (!generoCompleto.equals("Masculino") && !generoCompleto.equals("Femenino") && !generoCompleto.equals("Otro")) {
        	
            System.out.println("Introduzca solo una de las opciones válidas (Masculino/Femenino/Otro)");
            
            generoCompleto = scanner.nextLine();
        }

        char generoCaracter = generoCompleto.charAt(0);
        
        return generoCaracter;
        
		
	}
	
	private static LocalDate generarFechaNac() {
		
		Scanner scanner = new Scanner(System.in);	        

       DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
     
       LocalDate fechaNac = null;
       
       boolean fechaValida = false;                

       while (!fechaValida) {          	   
           
           String fechaNacInput = scanner.nextLine();

           try {
           	
               fechaNac = LocalDate.parse(fechaNacInput, dateFormatter);
               
               fechaValida = true;
               	                        
           } catch (DateTimeParseException e) {
           	
               System.out.println("Fecha no válida. Por favor, introduce una fecha con el formato indicado");
               
           }
       }
		
       return fechaNac;
       
	}

    private static void insertarAlumno() {
    	
        try (Connection conexion = conectarBaseDatos();
        		
            PreparedStatement ps = conexion.prepareStatement("INSERT INTO alumno (nia, nombre, apellidos, genero, fec_nac, ciclo, curso, GRUPO) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {

            Scanner scanner = new Scanner(System.in);
            
            System.out.println("Introduce el NIA del alumno: ");
            
            int nia = generarNIA();

            System.out.println("Introduce el nombre del alumno: ");
            
            String nombre = scanner.nextLine();

            System.out.println("Introduce los apellidos del alumno: ");
            
            String apellidos = scanner.nextLine();

            System.out.println("Introduce el género (Masculino/Femenino/Otro): ");
            
            char genero = generarLetraGenero();

            System.out.println("Introduce la fecha de nacimiento (dd/MM/yyyy): ");
            
            LocalDate fechaNacimiento = generarFechaNac();

            System.out.println("Introduce el ciclo del alumno: ");
            
            String ciclo = scanner.nextLine();

            System.out.println("Introduce el curso del alumno: ");
            
            String curso = scanner.nextLine();

            System.out.println("Introduce el id del grupo del alumno (ej: g1A grupo 1A): ");
            
            String grupo = scanner.nextLine();
   
            ps.setInt(1, nia);
            
            ps.setString(2, nombre);
            
            ps.setString(3, apellidos);
            
            ps.setString(4, String.valueOf(genero));
            
            ps.setDate(5, Date.valueOf(fechaNacimiento));
            
            ps.setString(6, ciclo);
            
            ps.setString(7, curso);
            
            ps.setString(8, grupo);

            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
            	
                System.out.println("Alumno insertado correctamente.");
                
            } else {
            	
                System.out.println("Error al insertar el alumno.");
                
            }

        } catch (SQLException e) {
        	
            e.printStackTrace();
            
        }
    }
    
    private static void insertarGrupo() {
    	
    	try(Connection conexion = conectarBaseDatos();

    		PreparedStatement ps = conexion.prepareStatement("INSERT INTO grupo (id, nombreGrupo) VALUES (?, ?)")){
    		
    		Scanner scanner = new Scanner(System.in);
    		
    		System.out.println("Introduzca el id del grupo");
    		
    		String idGrupo = scanner.nextLine();
    		
    		System.out.println("Introduzca el nombre del grupo");
    		
    		String nombreGrupo = scanner.nextLine();
    		
    		ps.setString(1, idGrupo);
    		
    		ps.setString(2, nombreGrupo);
    		
			int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
            	
                System.out.println("Grupo insertado correctamente.");
                
            } else {
            	
                System.out.println("Error al insertar el alumno.");
                
            }
    		
    	} catch (SQLException e) {

			e.printStackTrace();
			
		}
    	
    }

    private static void mostrarAlumnos() {
    	
        try (Connection conexion = conectarBaseDatos();
        		
             Statement statement = conexion.createStatement();
        		
        		 ResultSet rs = statement.executeQuery(
        				 
        	             "SELECT a.nia, a.nombre, a.apellidos, a.genero, a.fec_nac, a.ciclo, a.curso, a.grupo, g.nombreGrupo " +
        	             
        	             "FROM alumno a " +
        	            		 
        	             "INNER JOIN grupo g ON a.GRUPO = g.id"
        	             
        	         )) {

             System.out.println("Lista de alumnos:");
             
             System.out.println("");
             
             while (rs.next()) {
            	
                int nia = rs.getInt("nia");
                
                String nombre = rs.getString("nombre");
                
                String apellidos = rs.getString("apellidos");
                
                char genero = rs.getString("genero").charAt(0);
                
                //simpleformat
                
                LocalDate fechaNacimiento = rs.getDate("fec_nac").toLocalDate();
                
                String ciclo = rs.getString("ciclo");
                
                String curso = rs.getString("curso");
                
                String idGrupo = rs.getString("grupo");
                
                String nombreGrupo = rs.getString("nombreGrupo");

                System.out.println("NIA: " + nia + ", Nombre: " + nombre + ", Apellidos: " + apellidos +
                        
                		", Género: " + genero + ", Fecha Nacimiento: " + fechaNacimiento +
                        
                		", Ciclo: " + ciclo + ", Curso: " + curso + ", ID Grupo: " + idGrupo +
                        
                		", [Nombre Grupo: " + nombreGrupo +"]");
                
                    System.out.println("");
                
             }

        } catch (SQLException e) {
        	
            e.printStackTrace();
            
        }
    }
    
    private static void guardarEnFichero() {
    	
    	try (Connection conexion = conectarBaseDatos();
    			
    		 Statement statement = conexion.createStatement();
            
    			ResultSet rs = statement.executeQuery(
       				 
       	             "SELECT a.nia, a.nombre, a.apellidos, a.genero, a.fec_nac, a.ciclo, a.curso, a.grupo, g.nombreGrupo " +
       	             
       	             "FROM alumno a " +
       	            		 
       	             "INNER JOIN grupo g ON a.GRUPO = g.id"
       	             
       	         );
    			
    		 PrintWriter writer = new PrintWriter("fichero.txt")) {

                while (rs.next()) {
               	
                   int nia = rs.getInt("nia");
                   
                   String nombre = rs.getString("nombre");
                   
                   String apellidos = rs.getString("apellidos");
                   
                   char genero = rs.getString("genero").charAt(0);
                   
                   LocalDate fechaNacimiento = rs.getDate("fec_nac").toLocalDate();
                   
                   String ciclo = rs.getString("ciclo");
                   
                   String curso = rs.getString("curso");
                   
                   String grupo = rs.getString("grupo");
                   
                   String nombreGrupo = rs.getString("nombreGrupo");
                   
                   String linea = String.format("NIA: %d, Nombre: %s, Apellidos: %s, Género: %c, Fecha de Nacimiento: %s, Ciclo: %s, Curso: %s, Grupo: %s, Nombre de grupo: %s",
                		   
                           nia, nombre, apellidos, genero, fechaNacimiento, ciclo, curso, grupo, nombreGrupo);

                   writer.println(linea);
                                  
                }
                
                System.out.println("Se ha guardado todo correctamente");
                
                System.out.println("");
                
           } catch (SQLException e) {
           	
               System.out.println("Error al escribir en el archivo: " + e.getMessage());
               
               e.printStackTrace();
               
               
           } catch (Exception e) {
        	   
               System.out.println("Error al escribir en el archivo: " + e.getMessage());
               
               e.printStackTrace();
           }
    	
    }
    
    private static void pasarFicheroTXTAbd() {
    	
    	try (Connection conexion = conectarBaseDatos();
    			
       		 Statement statement = conexion.createStatement();
    		
       		 FileReader fr = new FileReader("fichero.txt");
    			
    		 BufferedReader br = new BufferedReader(fr)) {

    		 String linea;
            
    		while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(", ");

                int nia = Integer.parseInt(partes[0].split(": ")[1]);

                String nombre = partes[1].split(": ")[1];             
                
                String apellidos = partes[2].split(": ")[1];

                char genero = partes[3].split(": ")[1].charAt(0);
                
                String fechaNacimiento = partes[4].split(": ")[1];
                
                String ciclo = partes[5].split(": ")[1];
                
                String curso = partes[6].split(": ")[1];
                
                String idgrupo = partes[7].split(": ")[1];
                
                String nombreGrupo = partes[8].split(": ")[1];

                String sql1 = "INSERT INTO alumno (nia, nombre, apellidos, genero, fec_nac, ciclo, curso, grupo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
              
                try (PreparedStatement pstmt = conexion.prepareStatement(sql1)) {
                	
                    pstmt.setInt(1, nia);
                    
                    pstmt.setString(2, nombre);
                    
                    pstmt.setString(3, apellidos);
                    
                    pstmt.setString(4, String.valueOf(genero));
                    
                    pstmt.setDate(5, Date.valueOf(fechaNacimiento));
                    
                    pstmt.setString(6, ciclo);
                    
                    pstmt.setString(7, curso);
                    
                    pstmt.setString(8, idgrupo);
                    
                    pstmt.executeUpdate(); //para consultas que añaden o modifican datos como UPDATE O INSERT
                    
                } catch (SQLException e) {
                	
                    System.out.println("Error al insertar el alumno con NIA: " + nia);
                    
                    e.printStackTrace();
                    
                }
                
                String sql2 = "INSERT INTO grupo (id, nombreGrupo) VALUES (?, ?)";
               
				try (PreparedStatement pstmt = conexion.prepareStatement(sql2)) {
                	
                    pstmt.setString(1, idgrupo);
                    
                    pstmt.setString(2, nombreGrupo);
                    
                    pstmt.executeUpdate(); //para consultas que añaden o modifican datos como UPDATE O INSERT
                    
                } catch (SQLException e) {
                	
                    System.out.println("Error al insertar el alumno con NIA: " + nia);
                    
                    e.printStackTrace();
                    
                }
                
            }
            System.out.println("Todos los alumnos se han guardado en la base de datos.");

                 
              } catch (SQLException e) {
              	
                  System.out.println("Error al escribir en el archivo: " + e.getMessage());
                  
                  e.printStackTrace();
                  
                  
              } catch (Exception e) {
           	   
                  System.out.println("Error al escribir en el archivo: " + e.getMessage());
                  
                  e.printStackTrace();
              }
       	
       }
    
    private static void cambiarNombreDeAlumno() {

        Scanner scanner = new Scanner(System.in);
       
    	try (Connection conexion = conectarBaseDatos();
    			
          	 Statement statement = conexion.createStatement()){
    		
    			   System.out.println("Introduzca el nia del alumno al que le quiere cambiar el nombre");
    			   
    			   int niaIdentificatorio = scanner.nextInt();
    			   
    			   scanner.nextLine();
    			   
				   System.out.println("Introduzca el nuevo nombre del alumno");
					    			   
    			   String nombreNuevo = scanner.nextLine();
    			   
                   String sql = "UPDATE alumno SET nombre = ? WHERE nia = ?";
                   
                   try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
                   	
                       pstmt.setString(1, nombreNuevo);
                       
                       pstmt.setInt(2, niaIdentificatorio);
       
                       pstmt.executeUpdate();
                       
                   } catch (SQLException e) {
                   	
                       e.printStackTrace();
                       
                   }
                   
                   System.out.println("Se ha cambiado el nombre del alumno con el nia: " + niaIdentificatorio);
                   
                   System.out.println("");
                   
          } catch (SQLException e) {
            	
              System.out.println("Error al escribir en el archivo: " + e.getMessage());
              
              e.printStackTrace();
              
              
          }
    	
    }
    
    private static void eliminarAlumnoPorNia() {

        Scanner scanner = new Scanner(System.in);
       
    	try (Connection conexion = conectarBaseDatos();
    			
          	 Statement statement = conexion.createStatement()){
    		
    			   System.out.println("Introduzca el nia del alumno que quieres eliminar");
    			   
    			   int niaIdentificatorio = scanner.nextInt();
    			   
                   String sql = "DELETE FROM alumno WHERE nia = ?";
                   
                   try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {

                       pstmt.setInt(1, niaIdentificatorio);
       
                       pstmt.executeUpdate();
                       
                   } catch (SQLException e) {
                   	
                       e.printStackTrace();
                       
                   }
                   
                   System.out.println("El alumno con el nia: " + niaIdentificatorio + " ha sido eliminado");
                   
                   System.out.println("");
                   
          } catch (SQLException e) {
            	
              System.out.println("Error al escribir en el archivo: " + e.getMessage());
              
              e.printStackTrace();
              
              
          }
    	
    }
    
    private static void eliminarAlumnosPorGrupo() {

        Scanner scanner = new Scanner(System.in);
       
    	try (Connection conexion = conectarBaseDatos();
    			
    		 PreparedStatement pstmMostrar = conexion.prepareStatement("SELECT id, nombreGrupo FROM grupo");
				
        	 ResultSet rs=pstmMostrar.executeQuery()){
    		
    			   System.out.println("Introduzca un id de grupo, se eliminarán todos los alumnos que pertenezcan a ese grupo");
    			   
    			   System.out.println("");
    			   
    			   System.out.println("Lista de grupos disponibles: ");
    			   
    			   System.out.println("");
    			   
    			   while (rs.next()) {
    			   
					   String id = rs.getString("id");
	                   
	                   String nombreGrupo = rs.getString("nombreGrupo");
	    			   
	    			   String linea = String.format("id: %s, Nombre el grupo: %s",
	                		   
	                           id, nombreGrupo);
	    			   
	    			   System.out.println(linea);
	    			   
	    			   System.out.println("");
    			   
    			   }
    			   
    			   String idGrupo = scanner.nextLine();
    			   
                   String sqlDelete = "DELETE FROM alumno WHERE grupo like ?";
                   
                   try (PreparedStatement pstmtDelete = conexion.prepareStatement(sqlDelete);) {

                	    pstmtDelete.setString(1, idGrupo);
       
                	    pstmtDelete.executeUpdate();
                       
                   } catch (SQLException e) {
                   	
                       e.printStackTrace();
                       
                   }
                   
                   System.out.println("Los alumnos con el id " + idGrupo + " han sido eliminados");
                   
                   System.out.println("");
                   
          } catch (SQLException e) {
            	
              System.out.println("Error al escribir en el archivo: " + e.getMessage());
              
              e.printStackTrace();
              
              
          }
    	
    	}
    
	    private static void crearElementoAlumno(String datoAlumno, String valor, Element alumno, Document documento) {

	    	Attr atributo = documento.createAttribute(datoAlumno);
	        
	        atributo.setValue(valor);
	        
	        alumno.setAttributeNode(atributo);
			
		}
    	
	    private static void guardarEnFicheroXml() {
    		
	    	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	
	    	try (Connection conexion = conectarBaseDatos();
	    			
	    		 Statement statement = conexion.createStatement();
	            
	    		 ResultSet rs = statement.executeQuery( "SELECT a.nia, a.nombre, a.apellidos, a.genero, a.fec_nac, a.ciclo, a.curso, a.grupo, g.nombreGrupo " +
        	             
        	             "FROM alumno a " +
        	            		 
        	             "INNER JOIN grupo g ON a.GRUPO = g.id")){
	    			
		    		DocumentBuilder builder = factory.newDocumentBuilder();
		        	
					DOMImplementation implementation = builder.getDOMImplementation();
					
					Document document = implementation.createDocument(null, "Grupos", null);
					
					document.setXmlVersion("1.0");
					
					while (rs.next()) {
				
						Element grupoElement = document.createElement("Grupo");
			
						document.getDocumentElement().appendChild(grupoElement);
		
		                String id = rs.getString("grupo");
		                
		                String nombreGrupoG = rs.getString("nombreGrupo");
		               
						crearElementoAlumno("id", id, grupoElement, document);
								
						crearElementoAlumno("nombre", nombreGrupoG, grupoElement, document);
							
			            Element alumnoElement = document.createElement("Alumno");
			            
			            int nia = rs.getInt("nia");
			            
			            String nombre = rs.getString("nombre");
			            
			            String apellidos = rs.getString("apellidos");
			            
			            char genero = rs.getString("genero").charAt(0);
			            
			            LocalDate fechaNacimiento = rs.getDate("fec_nac").toLocalDate();
			            
			            String ciclo = rs.getString("ciclo");
			            
			            String curso = rs.getString("curso");

			            crearElementoAlumno("nia", String.valueOf(nia), alumnoElement, document);
			            
			            crearElementoAlumno("nombre", nombre, alumnoElement, document);
			            
			            crearElementoAlumno("apellidos", apellidos, alumnoElement, document);
			            
			            crearElementoAlumno("genero", String.valueOf(genero), alumnoElement, document);
			           
			            String fechaFormato = fechaNacimiento.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
			            
			            crearElementoAlumno("fechaNacimiento", fechaFormato, alumnoElement, document);
			            
			            crearElementoAlumno("ciclo", ciclo, alumnoElement, document);
			            
			            crearElementoAlumno("curso", curso, alumnoElement, document);

			            grupoElement.appendChild(alumnoElement);
						
					}
						
					Source source = new DOMSource(document);
					
					Result result  = new StreamResult(new java.io.File("tarea12.xml"));
					
					Transformer transformer = TransformerFactory.newInstance().newTransformer();						
						
					transformer.transform(source, result);
					
					System.out.println("El archivo xml se ha generado correctamente");
					
					} catch (SQLException e) {
		            	
			              System.out.println("Error al escribir en el archivo: " + e.getMessage());
			              
			              e.printStackTrace();			              
			              
			          } catch (ParserConfigurationException e) {

						e.printStackTrace();
						
					} catch (TransformerConfigurationException e) {

						e.printStackTrace();
						
					} catch (TransformerFactoryConfigurationError e) {

						e.printStackTrace();
						
					} catch (TransformerException e) {

						e.printStackTrace();
						
					} 

    		}
	    
	    private static void pasarFicheroXMLAbd() {
	    	
	        try (Connection conexion = conectarBaseDatos();
	        		
	             Statement statement = conexion.createStatement()) {	        	
	        	
	            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	            
	            DocumentBuilder builder = factory.newDocumentBuilder();

	            Document document = builder.parse(new File("tarea12.xml"));

	            NodeList gruposNodeList = document.getElementsByTagName("Grupo");

	            for (int i = 0; i < gruposNodeList.getLength(); i++) {
	            	
	            	Node grupoNode = gruposNodeList.item(i);

	                if (grupoNode.getNodeType() == Node.ELEMENT_NODE) {
	                	
	                    Element grupoElement = (Element) grupoNode;

	                    String grupoId = grupoElement.getAttribute("id");
	                   
	                    String grupoNombre = grupoElement.getAttribute("nombre");

	                    String grupoSql = "INSERT INTO grupo (id, nombreGrupo) VALUES (?, ?)";
	                    
	                    try (PreparedStatement pstmt = conexion.prepareStatement(grupoSql)) {
	                       
	                    	pstmt.setString(1, grupoId);
	                       
	                    	pstmt.setString(2, grupoNombre);
	                        
	                    	pstmt.executeUpdate();
	                       
	                    } catch (SQLException e) {
	                       
	                    	System.out.println("Error al insertar el grupo: " + e.getMessage());
	                    
	                    }
	            	
	                 NodeList alumnosNodeList = grupoElement.getElementsByTagName("Alumno");
	                    
	            	 for (int j = 0; j < alumnosNodeList.getLength();j++) {
	            	
		                Node alumnoNode = alumnosNodeList.item(i);
	
		                if (alumnoNode.getNodeType() == Node.ELEMENT_NODE) {
		                	
		                    Element alumnoElement = (Element) alumnoNode;
	
		                    int nia = Integer.parseInt(alumnoElement.getAttribute("nia"));
		                    
	                        String nombre = alumnoElement.getAttribute("nombre");
	                        
	                        String apellidos = alumnoElement.getAttribute("apellidos");
	                        
	                        String genero = alumnoElement.getAttribute("genero");
	                        
	                        String fechaNacimiento = alumnoElement.getAttribute("fechaNacimiento");
	                        
	                        String ciclo = alumnoElement.getAttribute("ciclo");
	                        
	                        String curso = alumnoElement.getAttribute("curso");
	                        
	                        String grupo = grupoId;
	
		                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		                    
		                    java.util.Date utilDate = sdf.parse(fechaNacimiento);
		                    
		                    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	
		                    String sql = "INSERT INTO alumno (nia, nombre, apellidos, genero, fec_nac, ciclo, curso, grupo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	
		                    try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
		                    	
		                        pstmt.setInt(1, nia);
		                        
		                        pstmt.setString(2, nombre);
		                        
		                        pstmt.setString(3, apellidos);
		                        
		                        pstmt.setString(4, genero);
		                        
		                        pstmt.setDate(5, sqlDate);
		                        
		                        pstmt.setString(6, ciclo);
		                        
		                        pstmt.setString(7, curso);
		                        
		                        pstmt.setString(8, grupo);
	
		                        pstmt.executeUpdate();
		                        
		                        System.out.println("Todos los alumnos se han guardado en la base de datos.");
		                        
		                    } catch (SQLException e) {
		                    	
		                        System.out.println("Error al insertar el alumno con NIA: " + nia);
		                        
		                        e.printStackTrace();
		                        
		                    }
		                }
		                
	            	 }
	            }
	                
	            }
	            
	        } catch (SQLException e) {
	        	
	            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
	            
	            e.printStackTrace();
	            
	        } catch (Exception e) {
	        	
	            System.out.println("Error al procesar el archivo XML: " + e.getMessage());
	            
	            e.printStackTrace();
	            
	        }
	    }

    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        
        int opcion=0;
        
        while(opcion != 11) {     	
        	  
            System.out.println("Menú:");
            
            System.out.println("1. Insertar nuevo alumno");
            
            System.out.println("2. Insertar nuevo grupo");
            
            System.out.println("3. Mostrar todos los alumnos con su grupo");
            
            System.out.println("4. Escribir los alumnos en un fichero txt");
            
            System.out.println("5. Escribir de fichero txt a base de datos");
            
            System.out.println("6. Modificar nombre a partir del nia");
            
            System.out.println("7. Eliminar alumno a partir de su nia");
                      
            System.out.println("8. Eliminar los alumnos del grupo indicado");
            
            System.out.println("9. Guardar los datos en un xml");
            
            System.out.println("10. Escribir de xml a base de datos");
            
            System.out.println("11. Salir");
            
            System.out.println("");
            
            System.out.print("Elige una opción: ");
            
            System.out.println("");
            
            opcion = Integer.parseInt(scanner.nextLine());
            
            System.out.println("");

            switch (opcion) {
            
                case 1:
                	
                    insertarAlumno();
                    
                    break;
                    
				case 2:
                	
                    insertarGrupo();
                    
                    break;
                    
                case 3:
                	
                    mostrarAlumnos();
                    
                    break;
                    
				case 4:
                	
                    guardarEnFichero();
                    
                    break;
                    
				case 5:
				                	
                    pasarFicheroTXTAbd();
                    
                    break;
                    
				case 6:
                	
					cambiarNombreDeAlumno();
                    
                    break;
                    
				case 7:
					
					eliminarAlumnoPorNia();
					
					break;
					
				case 8: 
					
					eliminarAlumnosPorGrupo();
					
					break;
                    
                case 9:
                	         	
                    guardarEnFicheroXml();
                    
                    break;
                    
                case 10:
                	
                	pasarFicheroXMLAbd();
                    
                    break;
                                       
                    
                case 11:
    	         	
                    System.out.println("Saliendo del programa...");
                    
                    break;
                  
            }
        } 
        
    }
    
}
//poner el simnple format y terminar lo del fichero txt que falta que tenga los grupos