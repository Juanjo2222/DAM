/**
 * 
 */
/**
 * 
 */
module TAREA12 {

	requires java.sql;
	requires java.xml;

}

